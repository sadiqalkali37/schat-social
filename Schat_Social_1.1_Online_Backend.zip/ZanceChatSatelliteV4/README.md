# Schat Social 1.1 — Android source + online-ready backend

Schat is an original social app concept combining username chat, a shared text feed, photo stories, short-video/Reels uploads and profiles in one black-and-gold interface. It is inspired by common social features; it does not embed or copy Facebook, WhatsApp, Instagram or TikTok, and is not affiliated with those services.

## New in 1.1
- Authenticated shared text posts (`POST /api/posts`, `GET /api/feed`).
- Authenticated image/video uploads (`POST /api/media`) with 50 MB per-file limit and basic MIME filtering.
- Story metadata expires from the story listing after 24 hours. (The underlying media file is not automatically deleted yet.)
- Media listing endpoint (`GET /api/media?kind=story|reel|post`) and static `/uploads/...` URLs.
- Android now publishes text posts to the API and uploads selected story photos/Reels when the user taps Upload.
- `render.yaml` provides a deployment blueprint with a persistent disk for the JSON database and media files.

## Deploy the backend (requires your own hosting account)
1. Create/sign in to a Render account and choose **New > Blueprint**.
2. Connect a Git repository containing this project and select `render.yaml`. The configured Starter service and persistent disk may incur charges; check the current price before creating it.
3. Wait for deployment, then open the service URL and check `/health`. The address must be HTTPS.
4. Open Schat > Settings and save that HTTPS service URL. Log in/register again if needed.
5. Test with two accounts: publish a text post, upload a photo story and upload a short video.

The blueprint generates a JWT secret. Keep it secret. Do not use the sample JSON database as a large public production system; migrate to a managed database and object storage/CDN before broad launch. Uploaded media is currently served publicly by URL, so do not upload private content. The app's UI does not yet render a full remote image/video feed; this version implements server-side sharing and uploads, not the full feature parity of the major social networks.

## Build an APK on your phone
This project includes `.github/workflows/build-apk.yml`. Upload the project folder to a GitHub repository, run **Build Schat APK** in Actions, and download the generated debug APK artifact after a successful run. The ZIP itself is source code, not an installable APK. A successful cloud build has not yet been verified.

## Prototype limits
- Backend JSON-file storage is intended for testing; use PostgreSQL and durable object storage for production.
- Upload limit is 50 MB per file; stories currently accept photos, Reels accept videos.
- Story records expire after 24 hours, but their stored files are not automatically deleted yet.
- Likes, comments, moderation/reporting, push notifications, end-to-end encryption, full remote media playback, and satellite connectivity are not implemented.
