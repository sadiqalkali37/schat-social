import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import multer from "multer";

const app = express();
app.use(express.json({ limit: "32kb" }));
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.resolve("uploads");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => cb(null, `${crypto.randomUUID()}${path.extname(file.originalname).toLowerCase().slice(0, 10)}`)
  }),
  limits: { fileSize: 50 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ok = /^(image\/(jpeg|png|webp|gif)|video\/(mp4|webm|quicktime|3gpp))$/.test(file.mimetype);
    cb(ok ? null : new Error("Only supported image and video files are allowed"), ok);
  }
});

const PORT = Number(process.env.PORT || 8080);
const JWT_SECRET = process.env.JWT_SECRET;
const DATA_FILE = process.env.DATA_FILE || path.resolve("data.json");
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET to a random secret of at least 32 characters before starting.");
  process.exit(1);
}
function loadDb() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { users: [], messages: [], contacts: {}, posts: [], media: [] }; }
}
let db = loadDb();
db.posts ||= []; db.media ||= []; db.contacts ||= {}; db.messages ||= []; db.users ||= [];
function saveDb() {
  const tmp = DATA_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DATA_FILE);
}
function normalizeUsername(v) {
  return String(v || "").trim().toLowerCase().replace(/^@/, "");
}
function validUsername(v) { return /^[a-z0-9_.]{3,24}$/.test(v); }
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.users.find(u => u.id === payload.sub);
    if (!user) return res.status(401).json({ error: "Account not found" });
    req.user = user;
    next();
  } catch { return res.status(401).json({ error: "Please log in again" }); }
}
const attempts = new Map();
function loginLimit(req, res, next) {
  const ip = req.ip || "unknown", now = Date.now();
  const item = attempts.get(ip) || { count: 0, start: now };
  if (now - item.start > 60_000) { item.count = 0; item.start = now; }
  item.count++;
  attempts.set(ip, item);
  if (item.count > 30) return res.status(429).json({ error: "Too many attempts; try again later" });
  next();
}
app.get("/health", (_req, res) => res.json({ ok: true, service: "Schat API", features: ["chat", "feed", "stories", "reels", "media-upload"] }));
app.use("/uploads", express.static(UPLOAD_DIR, { maxAge: "1h", immutable: false, fallthrough: false }));

app.post("/api/posts", auth, (req, res) => {
  const body = String(req.body.body || "").trim();
  if (!body || body.length > 2000) return res.status(400).json({ error: "Post must be 1–2000 characters" });
  const post = { id: crypto.randomUUID(), username: req.user.username, displayName: req.user.displayName, body, time: Date.now() };
  db.posts.unshift(post); db.posts = db.posts.slice(0, 5000); saveDb();
  res.status(201).json({ post });
});
app.get("/api/feed", auth, (_req, res) => {
  res.json({ posts: db.posts.slice(0, 100) });
});
app.post("/api/media", auth, (req, res) => {
  upload.single("file")(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || "Upload failed" });
    if (!req.file) return res.status(400).json({ error: "Choose a photo or video first" });
    const kind = String(req.body.kind || "").toLowerCase();
    if (!["story", "reel", "post"].includes(kind)) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({ error: "Media kind must be story, reel or post" });
    }
    if (kind === "story" && !req.file.mimetype.startsWith("image/")) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({ error: "Stories currently support photos only" });
    }
    if (kind === "reel" && !req.file.mimetype.startsWith("video/")) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({ error: "Reels require a video file" });
    }
    const item = { id: crypto.randomUUID(), username: req.user.username, displayName: req.user.displayName,
      kind, mimeType: req.file.mimetype, url: `/uploads/${req.file.filename}`, time: Date.now(),
      expiresAt: kind === "story" ? Date.now() + 24 * 60 * 60 * 1000 : null };
    db.media.unshift(item); db.media = db.media.slice(0, 10000); saveDb();
    res.status(201).json({ media: item });
  });
});
app.get("/api/media", auth, (req, res) => {
  const kind = String(req.query.kind || "").toLowerCase();
  const now = Date.now();
  const media = db.media.filter(m => (!kind || m.kind === kind) && (!m.expiresAt || m.expiresAt > now)).slice(0, 100);
  res.json({ media });
});

app.post("/api/register", loginLimit, async (req, res) => {
  const username = normalizeUsername(req.body.username);
  const displayName = String(req.body.displayName || username).trim().slice(0, 48);
  const password = String(req.body.password || "");
  if (!validUsername(username)) return res.status(400).json({ error: "Username must be 3–24 characters: letters, numbers, dot or underscore" });
  if (password.length < 8 || password.length > 128) return res.status(400).json({ error: "Password must be 8–128 characters" });
  if (db.users.some(u => u.username === username)) return res.status(409).json({ error: "That username is already taken" });
  const user = { id: crypto.randomUUID(), username, displayName, passwordHash: await bcrypt.hash(password, 12), createdAt: Date.now() };
  db.users.push(user);
  db.contacts[user.id] = [];
  saveDb();
  const token = jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: "7d" });
  res.status(201).json({ token, username, displayName });
});

app.post("/api/login", loginLimit, async (req, res) => {
  const username = normalizeUsername(req.body.username);
  const password = String(req.body.password || "");
  const user = db.users.find(u => u.username === username);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ error: "Incorrect username or password" });
  const token = jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: "7d" });
  res.json({ token, username: user.username, displayName: user.displayName });
});

app.get("/api/users/:username", auth, (req, res) => {
  const username = normalizeUsername(req.params.username);
  const user = db.users.find(u => u.username === username);
  if (!user) return res.status(404).json({ error: "Username not found" });
  res.json({ username: user.username, displayName: user.displayName });
});

app.post("/api/contacts", auth, (req, res) => {
  const username = normalizeUsername(req.body.username);
  const other = db.users.find(u => u.username === username);
  if (!other) return res.status(404).json({ error: "No account uses that username" });
  if (other.id === req.user.id) return res.status(400).json({ error: "You cannot add yourself" });
  const ids = db.contacts[req.user.id] || [];
  if (!ids.includes(other.id)) ids.push(other.id);
  db.contacts[req.user.id] = ids;
  saveDb();
  res.json({ ok: true, contact: { username: other.username, displayName: other.displayName } });
});

app.get("/api/contacts", auth, (req, res) => {
  const ids = db.contacts[req.user.id] || [];
  const contacts = ids.map(id => db.users.find(u => u.id === id)).filter(Boolean)
    .map(u => ({ username: u.username, displayName: u.displayName }));
  res.json({ contacts });
});

app.post("/api/messages", auth, (req, res) => {
  const recipientUsername = normalizeUsername(req.body.recipientUsername);
  const body = String(req.body.body || "").trim();
  if (!body || body.length > 4000) return res.status(400).json({ error: "Message must be 1–4000 characters" });
  const recipient = db.users.find(u => u.username === recipientUsername);
  if (!recipient) return res.status(404).json({ error: "Recipient username not found" });
  if (recipient.id === req.user.id) return res.status(400).json({ error: "You cannot message yourself" });
  const message = {
    id: crypto.randomUUID(), senderId: req.user.id, recipientId: recipient.id,
    senderUsername: req.user.username, recipientUsername: recipient.username,
    body, time: Date.now()
  };
  db.messages.push(message);
  saveDb();
  res.status(201).json({ ok: true, id: message.id, time: message.time });
});

app.get("/api/messages/:username", auth, (req, res) => {
  const otherUsername = normalizeUsername(req.params.username);
  const other = db.users.find(u => u.username === otherUsername);
  if (!other) return res.status(404).json({ error: "Recipient username not found" });
  const isContact = (db.contacts[req.user.id] || []).includes(other.id) || (db.contacts[other.id] || []).includes(req.user.id);
  const related = db.messages.filter(m =>
    (m.senderId === req.user.id && m.recipientId === other.id) ||
    (m.senderId === other.id && m.recipientId === req.user.id)
  );
  if (!isContact && related.length === 0) return res.json({ messages: [] });
  res.json({ messages: related.map(({ id, senderUsername, recipientUsername, body, time }) => ({ id, senderUsername, recipientUsername, body, time })).sort((a,b) => a.time - b.time) });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error" });
});
app.listen(PORT, "0.0.0.0", () => console.log(`ZanceChat API listening on port ${PORT}`));
