# Schat: phone-only build and backend guide

## Get the Android APK
1. Extract this ZIP on your phone.
2. Create a GitHub account if you do not already have one, then create a repository and upload the extracted project files.
3. In the repository, open **Actions** and run **Build Schat APK**.
4. When the workflow finishes successfully, open its run and download the `Schat-1.1-debug-apk` artifact. Extract the artifact ZIP and install the APK. Android may ask you to allow installation from your browser/file manager.

## Put Schat online
1. Create a Render account and connect the GitHub repository as a Blueprint using the included `render.yaml`. This configuration uses a paid web service and persistent disk; review the price first.
2. Wait for the deployment to finish. Open the service URL plus `/health`; it should return JSON with `ok: true`.
3. In Schat, open Settings and paste the service's HTTPS URL, save, then register/login.
4. Text posts, photo stories and video uploads use the online backend once configured. Keep uploaded media public only; anyone with a media URL may be able to view it.

## Important
- You must own the GitHub and hosting accounts and approve any charges; I cannot sign up or deploy to those accounts on your behalf from this chat.
- The ZIP is source code, not an already compiled APK. The cloud build has not been verified yet.
- This is an early prototype. It does not yet include a complete remote photo/video viewing feed, likes/comments, push notifications, end-to-end encryption or satellite connectivity.
