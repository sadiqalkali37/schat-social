package com.sua.schat

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Gold = Color(0xFFE2B84B)
private val Muted = Color(0xFFB9B9B9)
private val White = Color(0xFFF7F4EA)

data class PublicUser(val username: String, val displayName: String)
data class Message(val id: String, val sender: String, val recipient: String, val body: String, val time: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZanceApp(applicationContext) }
    }
}

class Api(private val base: String) {
    private fun call(path: String, method: String = "GET", token: String? = null, payload: JSONObject? = null): JSONObject {
        val conn = (URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 10000
            readTimeout = 10000
            setRequestProperty("Content-Type", "application/json")
            if (token != null) setRequestProperty("Authorization", "Bearer $token")
            if (payload != null) doOutput = true
        }
        if (payload != null) conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        conn.disconnect()
        val obj = try { JSONObject(raw) } catch (_: Exception) { JSONObject().put("raw", raw) }
        if (code !in 200..299) throw Exception(obj.optString("error", "Server returned HTTP $code"))
        return obj
    }
    fun register(user: String, display: String, password: String) = call("/api/register", "POST", payload = JSONObject().put("username", user).put("displayName", display).put("password", password))
    fun login(user: String, password: String) = call("/api/login", "POST", payload = JSONObject().put("username", user).put("password", password))
    fun findUser(token: String, username: String) = call("/api/users/${enc(username)}", token = token)
    fun send(token: String, recipient: String, body: String) = call("/api/messages", "POST", token, JSONObject().put("recipientUsername", recipient).put("body", body))
    fun getMessages(token: String, other: String): List<Message> {
        val arr = call("/api/messages/${enc(other)}", token = token).optJSONArray("messages") ?: JSONArray()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Message(o.optString("id"), o.optString("senderUsername"), o.optString("recipientUsername"), o.optString("body"), o.optLong("time"))
        }
    }
    fun contacts(token: String): List<PublicUser> {
        val arr = call("/api/contacts", token = token).optJSONArray("contacts") ?: JSONArray()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i); PublicUser(o.optString("username"), o.optString("displayName"))
        }
    }
    fun addContact(token: String, username: String) = call("/api/contacts", "POST", token, JSONObject().put("username", username))
    fun publishPost(token: String, body: String) = call("/api/posts", "POST", token, JSONObject().put("body", body))
    fun getFeed(token: String): List<String> {
        val arr = call("/api/feed", token = token).optJSONArray("posts") ?: JSONArray()
        return (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); "@${o.optString("username")}: ${o.optString("body")}" }
    }
    fun uploadMedia(token: String, uri: Uri, kind: String, resolver: android.content.ContentResolver): JSONObject {
        val mime = resolver.getType(uri) ?: if (kind == "reel") "video/mp4" else "image/jpeg"
        val ext = when { mime.contains("png") -> "png"; mime.contains("webp") -> "webp"; mime.contains("quicktime") -> "mov"; mime.contains("webm") -> "webm"; mime.startsWith("video/") -> "mp4"; else -> "jpg" }
        val boundary = "SchatBoundary${System.currentTimeMillis()}"
        val conn = (URL(base.trimEnd('/') + "/api/media").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        DataOutputStream(conn.outputStream).use { out ->
            out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"kind\"\r\n\r\n$kind\r\n")
            out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"upload.$ext\"\r\nContent-Type: $mime\r\n\r\n")
            resolver.openInputStream(uri)?.use { input -> val buffer = ByteArray(8192); while (true) { val n = input.read(buffer); if (n < 0) break; out.write(buffer, 0, n) } } ?: throw Exception("Could not read selected media")
            out.writeBytes("\r\n--$boundary--\r\n")
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        conn.disconnect()
        val obj = try { JSONObject(raw) } catch (_: Exception) { JSONObject().put("raw", raw) }
        if (code !in 200..299) throw Exception(obj.optString("error", "Upload failed (HTTP $code)"))
        return obj
    }
    companion object {
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    }
}
fun enc(s: String) = Api.enc(s)

@Composable
fun ZanceApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("schat_v1", Context.MODE_PRIVATE) }
    var baseUrl by remember { mutableStateOf(prefs.getString("baseUrl", "") ?: "") }
    var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    var username by remember { mutableStateOf(prefs.getString("username", "") ?: "") }
    var displayName by remember { mutableStateOf(prefs.getString("displayName", "") ?: "") }
    var screen by remember { mutableStateOf(if (token.isBlank()) "auth" else "home") }
    var authMode by remember { mutableStateOf("login") }
    var inputUser by remember { mutableStateOf("") }
    var inputDisplay by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var searchUser by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Connect to your server to begin") }
    var busy by remember { mutableStateOf(false) }
    var contacts by remember { mutableStateOf(listOf<PublicUser>()) }
    var messages by remember { mutableStateOf(listOf<Message>()) }
    var settingsUrl by remember { mutableStateOf(baseUrl) }
    var error by remember { mutableStateOf("") }
    var postDraft by remember { mutableStateOf("") }
    var socialPosts by remember { mutableStateOf(listOf("Welcome to Schat — your social world in one place.")) }
    var storyMedia by remember { mutableStateOf("") }
    var reelMedia by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val storyPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { storyMedia = uri.toString(); status = "Photo selected. Tap Upload story to share it online." }
    }
    val reelPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { reelMedia = uri.toString(); status = "Video selected. Tap Upload Reel to share it online." }
    }

    fun apiOrNull(): Api? = if (baseUrl.startsWith("https://")) Api(baseUrl) else null
    fun loadContacts() {
        val api = apiOrNull()
        if (api == null || token.isBlank()) { status = "Set an HTTPS server URL in Settings"; return }
        busy = true
        scope.launch(Dispatchers.IO) {
            try { val result = api.contacts(token)
                withContext(Dispatchers.Main) { contacts = result; status = "Contacts updated"; busy = false }
            } catch (e: Exception) { withContext(Dispatchers.Main) { status = e.message ?: "Could not load contacts"; busy = false } }
        }
    }
    fun loadMessages(other: String) {
        val api = apiOrNull()
        if (api == null || token.isBlank()) { status = "Set an HTTPS server URL in Settings"; return }
        busy = true
        scope.launch(Dispatchers.IO) {
            try { val result = api.getMessages(token, other)
                withContext(Dispatchers.Main) { messages = result; status = "Loaded ${result.size} message(s)"; busy = false }
            } catch (e: Exception) { withContext(Dispatchers.Main) { status = e.message ?: "Could not load messages"; busy = false } }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Black, surface = Panel, onPrimary = Black, onBackground = White, onSurface = White)) {
        Surface(Modifier.fillMaxSize(), color = Black) {
            when (screen) {
                "auth" -> AuthScreen(authMode, { authMode = it; error = "" }, inputUser, { inputUser = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' || c == '.' } },
                    inputDisplay, { inputDisplay = it }, password, { password = it }, error, baseUrl,
                    onServer = { screen = "settings" },
                    onSubmit = {
                        val api = apiOrNull()
                        if (api == null) { error = "First set a valid HTTPS server URL in Settings"; return@AuthScreen }
                        if (inputUser.length < 3 || password.length < 8) { error = "Username must be 3+ characters and password at least 8 characters"; return@AuthScreen }
                        busy = true
                        scope.launch(Dispatchers.IO) {
                            try {
                                val result = if (authMode == "register") api.register(inputUser, inputDisplay.ifBlank { inputUser }, password) else api.login(inputUser, password)
                                withContext(Dispatchers.Main) {
                                    token = result.optString("token")
                                    username = result.optString("username", inputUser)
                                    displayName = result.optString("displayName", inputDisplay.ifBlank { username })
                                    prefs.edit().putString("token", token).putString("username", username).putString("displayName", displayName).apply()
                                    password = ""; error = ""; busy = false; screen = "home"; status = "Signed in as @$username"
                                    loadContacts()
                                }
                            } catch (e: Exception) { withContext(Dispatchers.Main) { error = e.message ?: "Authentication failed"; busy = false } }
                        }
                    })
                "home" -> HomeScreen(username, displayName, contacts, status, busy,
                    onOpen = { target = it.username; screen = "chat"; loadMessages(it.username) },
                    onAdd = { screen = "add" }, onSettings = { settingsUrl = baseUrl; screen = "settings" },
                    onSatellite = { screen = "satellite" }, onRefresh = { loadContacts() },
                    onSocial = {
                        screen = "social"
                        val api = apiOrNull()
                        if (api != null && token.isNotBlank()) {
                            busy = true
                            scope.launch(Dispatchers.IO) {
                                try { val feed = api.getFeed(token); withContext(Dispatchers.Main) { socialPosts = feed; busy = false } }
                                catch (e: Exception) { withContext(Dispatchers.Main) { status = e.message ?: "Could not load feed"; busy = false } }
                            }
                        }
                    },
                    onLogout = { token = ""; prefs.edit().remove("token").apply(); screen = "auth"; authMode = "login" })
                "social" -> SchatSocialScreen(
                    user = username, posts = socialPosts, postDraft = postDraft,
                    setPostDraft = { postDraft = it }, storyMedia = storyMedia, reelMedia = reelMedia, status = status,
                    onBack = { screen = "home" }, onOpenChats = { screen = "home" },
                    onPickStory = { storyPicker.launch("image/*") }, onPickReel = { reelPicker.launch("video/*") },
                    onPublish = {
                        val body = postDraft.trim(); val api = apiOrNull()
                        if (body.isBlank()) status = "Write something first"
                        else if (api == null || token.isBlank()) status = "Set the HTTPS server URL and sign in"
                        else { busy = true; scope.launch(Dispatchers.IO) { try { api.publishPost(token, body); val feed = api.getFeed(token); withContext(Dispatchers.Main) { socialPosts = feed; postDraft = ""; status = "Post shared with Schat users"; busy = false } } catch (e: Exception) { withContext(Dispatchers.Main) { status = e.message ?: "Could not publish post"; busy = false } } } }
                    },
                    onUploadStory = { uploadSelectedMedia(storyMedia, "story", token, baseUrl, context, scope, { status = it }, { busy = it }) },
                    onUploadReel = { uploadSelectedMedia(reelMedia, "reel", token, baseUrl, context, scope, { status = it }, { busy = it }) }
                )
                "add" -> AddContactScreen(searchUser, { searchUser = it.lowercase().removePrefix("@") }, error, { error = "" },
                    onBack = { screen = "home" }, onAdd = {
                        val api = apiOrNull()
                        if (api == null) { error = "Set server URL in Settings"; return@AddContactScreen }
                        busy = true
                        scope.launch(Dispatchers.IO) {
                            try { api.addContact(token, searchUser.trim())
                                withContext(Dispatchers.Main) { target = searchUser.trim(); searchUser = ""; error = ""; busy = false; screen = "chat"; loadMessages(target) }
                            } catch (e: Exception) { withContext(Dispatchers.Main) { error = e.message ?: "Could not add contact"; busy = false } }
                        }
                    })
                "chat" -> ChatScreen(username, target, messages, draft, status, busy, { screen = "home" }, { draft = it },
                    { loadMessages(target) }, {
                        val body = draft.trim(); val api = apiOrNull()
                        if (body.isNotEmpty() && api != null) {
                            busy = true
                            scope.launch(Dispatchers.IO) {
                                try { api.send(token, target, body); val updated = api.getMessages(token, target)
                                    withContext(Dispatchers.Main) { messages = updated; draft = ""; status = "Message sent"; busy = false }
                                } catch (e: Exception) { withContext(Dispatchers.Main) { status = e.message ?: "Send failed"; busy = false } }
                            }
                        } else status = "Set server URL to send real messages"
                    })
                "settings" -> SettingsScreen(settingsUrl, { settingsUrl = it }, username, displayName,
                    onBack = { screen = if (token.isBlank()) "auth" else "home" },
                    onSave = { url ->
                        if (!url.startsWith("https://")) status = "Server URL must start with https://"
                        else { baseUrl = url.trimEnd('/'); prefs.edit().putString("baseUrl", baseUrl).apply(); status = "Server URL saved"; screen = if (token.isBlank()) "auth" else "home" }
                    })
                else -> SatelliteScreen { screen = "home" }
            }
        }
    }
}

fun uploadSelectedMedia(uriText: String, kind: String, token: String, baseUrl: String, context: Context, scope: kotlinx.coroutines.CoroutineScope, setStatus: (String) -> Unit, setBusy: (Boolean) -> Unit) {
    if (uriText.isBlank()) { setStatus(if (kind == "story") "Choose a photo first" else "Choose a video first"); return }
    if (!baseUrl.startsWith("https://") || token.isBlank()) { setStatus("Set the HTTPS server URL and sign in"); return }
    setBusy(true)
    scope.launch(Dispatchers.IO) {
        try {
            Api(baseUrl).uploadMedia(token, Uri.parse(uriText), kind, context.contentResolver)
            withContext(Dispatchers.Main) { setStatus(if (kind == "story") "Story uploaded! It expires after 24 hours." else "Reel uploaded to Schat!"); setBusy(false) }
        } catch (e: Exception) { withContext(Dispatchers.Main) { setStatus(e.message ?: "Upload failed"); setBusy(false) } }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null, back: (() -> Unit)? = null, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().background(Black).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) { IconButtonGold(back) { Icon(Icons.Default.ArrowBack, null, tint = Gold) }; Spacer(Modifier.width(8.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        if (action != null) action()
    }
}
@Composable
fun IconButtonGold(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(38.dp).background(Panel, CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) { content() }
}
@Composable
fun AuthScreen(mode: String, setMode: (String) -> Unit, user: String, setUser: (String) -> Unit, display: String, setDisplay: (String) -> Unit, password: String, setPassword: (String) -> Unit, error: String, baseUrl: String, onServer: () -> Unit, onSubmit: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Black).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Schat", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Username-based messaging", color = Muted)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(selected = mode == "login", onClick = { setMode("login") }, label = { Text("Log in") })
            FilterChip(selected = mode == "register", onClick = { setMode("register") }, label = { Text("Create account") })
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(user, setUser, modifier = Modifier.fillMaxWidth(), label = { Text("@username") }, singleLine = true, colors = fieldColors())
        if (mode == "register") OutlinedTextField(display, setDisplay, modifier = Modifier.fillMaxWidth(), label = { Text("Display name (optional)") }, singleLine = true, colors = fieldColors())
        OutlinedTextField(password, setPassword, modifier = Modifier.fillMaxWidth(), label = { Text("Password (8+ characters)") }, singleLine = true, colors = fieldColors())
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF7777), fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Button(onClick = onSubmit, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text(if (mode == "register") "Create account" else "Log in") }
        Text("Server: ${if (baseUrl.isBlank()) "not configured" else baseUrl}", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
        TextButton(onClick = onServer) { Text("Configure server", color = Gold) }
    }
}
@Composable
fun HomeScreen(user: String, display: String, contacts: List<PublicUser>, status: String, busy: Boolean, onOpen: (PublicUser) -> Unit, onAdd: () -> Unit, onSettings: () -> Unit, onSatellite: () -> Unit, onRefresh: () -> Unit, onSocial: () -> Unit, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Black)) {
        Header("ZanceChat 4.0", "@$user • ${display.ifBlank { user }}", action = {
            IconButtonGold(onLogout) { Icon(Icons.Default.Logout, "Log out", tint = Gold) }
        })
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionCard("New chat", "Find username", onAdd, Modifier.weight(1f), Icons.Default.Add)
            ActionCard("Settings", "Server settings", onSettings, Modifier.weight(1f), Icons.Default.Settings)
            ActionCard("Satellite", "Provider info", onSatellite, Modifier.weight(1f), Icons.Default.SatelliteAlt)
        }
        Button(onClick = onSocial, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) {
            Text("Open Schat Social • Feed, Stories & Reels", fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().clickable { onRefresh() }.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Sync, null, tint = Gold); Spacer(Modifier.width(8.dp)); Text(if (busy) "Syncing…" else "Refresh contacts", color = White)
        }
        Text("CONTACTS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 18.dp, top = 8.dp, bottom = 8.dp))
        if (contacts.isEmpty()) Text("No contacts yet. Tap New chat to add someone by username.", color = Muted, modifier = Modifier.padding(18.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(contacts) { c ->
                Row(Modifier.fillMaxWidth().clickable { onOpen(c) }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Gold, CircleShape), contentAlignment = Alignment.Center) { Text(c.username.take(2).uppercase(), color = Black, fontWeight = FontWeight.Bold) }
                    Column(Modifier.padding(start = 12.dp).weight(1f)) {
                        Text(c.displayName, color = White, fontWeight = FontWeight.SemiBold)
                        Text("@${c.username}", color = Muted, fontSize = 12.sp)
                    }
                    Text("CHAT", color = Gold, fontSize = 10.sp)
                }
                HorizontalDivider(color = Panel, modifier = Modifier.padding(start = 76.dp))
            }
        }
        Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(12.dp).align(Alignment.CenterHorizontally))
    }
}
@Composable
fun ActionCard(title: String, desc: String, onClick: () -> Unit, modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(12.dp)) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(22.dp)); Spacer(Modifier.height(8.dp))
        Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(desc, color = Muted, fontSize = 10.sp)
    }
}
@Composable
fun AddContactScreen(value: String, setValue: (String) -> Unit, error: String, clearError: () -> Unit, onBack: () -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Black)) {
        Header("New chat", "FIND A USERNAME", onBack)
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Enter their username", color = Gold, fontWeight = FontWeight.Bold)
            OutlinedTextField(value, { setValue(it); clearError() }, modifier = Modifier.fillMaxWidth(), label = { Text("@username") }, singleLine = true, colors = fieldColors())
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF7777), fontSize = 12.sp)
            Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text("Find and add contact") }
        }
    }
}
@Composable
fun ChatScreen(user: String, target: String, messages: List<Message>, draft: String, status: String, busy: Boolean, onBack: () -> Unit, setDraft: (String) -> Unit, onRefresh: () -> Unit, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Black)) {
        Header("@$target", "Signed in as @$user", onBack) { IconButtonGold(onRefresh) { Icon(Icons.Default.Sync, "Refresh messages", tint = Gold) } }
        Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (messages.isEmpty()) item { Text("No messages yet. Send a message or refresh.", color = Muted, fontSize = 13.sp) }
            items(messages) { m ->
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text("@${m.sender}", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(m.body, color = White, fontSize = 15.sp)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp).background(Panel, RoundedCornerShape(24.dp)).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(draft, setDraft, modifier = Modifier.weight(1f), textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp), decorationBox = { inner -> if (draft.isEmpty()) Text("Message @$target…", color = Muted); inner() })
            Spacer(Modifier.width(8.dp))
            IconButtonGold(onSend) { if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Gold, strokeWidth = 2.dp) else Icon(Icons.Default.Send, "Send", tint = Gold) }
        }
    }
}
@Composable
fun SchatSocialScreen(
    user: String,
    posts: List<String>,
    postDraft: String,
    setPostDraft: (String) -> Unit,
    storyMedia: String,
    reelMedia: String,
    status: String,
    onBack: () -> Unit,
    onOpenChats: () -> Unit,
    onPickStory: () -> Unit,
    onPickReel: () -> Unit,
    onPublish: () -> Unit,
    onUploadStory: () -> Unit,
    onUploadReel: () -> Unit
) {
    var tab by remember { mutableStateOf("Feed") }
    Column(Modifier.fillMaxSize().background(Black)) {
        Header("Schat", "ONE SOCIAL WORLD • @$user", onBack) {
            TextButton(onClick = onOpenChats) { Text("Chats", color = Gold, fontWeight = FontWeight.Bold) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Feed", "Stories", "Reels", "Profile").forEach { name ->
                FilterChip(selected = tab == name, onClick = { tab = name }, label = { Text(name) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = Black))
            }
        }
        when (tab) {
            "Feed" -> {
                Column(Modifier.fillMaxWidth().padding(12.dp).background(Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
                    Text("What's happening?", color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(postDraft, setPostDraft, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Share a thought with Schat…") }, colors = fieldColors())
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onPublish, modifier = Modifier.align(Alignment.End), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text("Publish post") }
                }
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(posts) { post ->
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
                            Text("@$user", color = Gold, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp)); Text(post, color = White, fontSize = 15.sp)
                            Spacer(Modifier.height(10.dp)); Text("♡ Like     ◯ Comment     ↗ Share", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
            "Stories" -> {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Stories disappear after 24 hours in a fully deployed version.", color = Muted)
                    Button(onClick = onPickStory, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text("＋ Choose photo for story") }
                    if (storyMedia.isNotBlank()) {
                        Text("Selected story media", color = Gold, fontWeight = FontWeight.Bold)
                        Text(storyMedia.substringAfterLast('/').take(80), color = White, fontSize = 12.sp)
                        TextButton(onClick = onUploadStory) { Text("Upload story", color = Gold) }
                    }
                    Text(status, color = Muted, fontSize = 12.sp)
                    Text("Your story ring", color = Gold, fontWeight = FontWeight.Bold)
                    Text("◎  Your story", color = White)
                }
            }
            "Reels" -> {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Short vertical videos, inspired by modern video feeds.", color = Muted)
                    Button(onClick = onPickReel, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text("＋ Choose video for a Reel") }
                    if (reelMedia.isNotBlank()) {
                        Text("Selected video", color = Gold, fontWeight = FontWeight.Bold)
                        Text(reelMedia.substringAfterLast('/').take(80), color = White, fontSize = 12.sp)
                        TextButton(onClick = onUploadReel) { Text("Upload Reel", color = Gold) }
                    }
                    Text(status, color = Muted, fontSize = 12.sp)
                    Box(Modifier.fillMaxWidth().height(220.dp).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                        Text("SCHAT REELS\nShort videos • Discover • Share", color = Gold, fontWeight = FontWeight.Bold)
                    }
                }
            }
            else -> {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(72.dp).background(Gold, CircleShape), contentAlignment = Alignment.Center) { Text(user.take(2).uppercase(), color = Black, fontWeight = FontWeight.Bold, fontSize = 24.sp) }
                    Text("@$user", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("Posts: ${posts.size}   •   Stories: ready to add   •   Reels: ready to add", color = White)
                    Text("Your Schat profile is the home for your posts and media.", color = Muted)
                }
            }
        }
        Text("Online feed and media sharing require your deployed HTTPS server with persistent storage.", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth().padding(8.dp))
    }
}

@Composable
fun SettingsScreen(url: String, setUrl: (String) -> Unit, username: String, display: String, onBack: () -> Unit, onSave: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(Black)) {
        Header("Settings", "SERVER CONNECTION", onBack)
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Server base URL", color = Gold, fontWeight = FontWeight.Bold)
            OutlinedTextField(url, setUrl, modifier = Modifier.fillMaxWidth(), label = { Text("https://your-server.example") }, singleLine = true, colors = fieldColors())
            Text("Current account: @$username (${display.ifBlank { username }})", color = Muted, fontSize = 12.sp)
            Text("A deployed backend is required for accounts and real cross-phone messaging. Use HTTPS.", color = Muted, fontSize = 12.sp)
            Button(onClick = { onSave(url) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text("Save server URL") }
        }
    }
}
@Composable
fun SatelliteScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Black)) {
        Header("Satellite status", "DEVICE & NETWORK", onBack)
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Provider not connected", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Satellite messaging is not implemented in this release. It requires compatible phone or external hardware, supported provider coverage and subscription, and an approved integration.", color = White)
        }
    }
}
@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = White, unfocusedTextColor = White,
    focusedBorderColor = Gold, unfocusedBorderColor = Muted,
    focusedLabelColor = Gold, unfocusedLabelColor = Muted, cursorColor = Gold
)
